package com.Employee.EmployeeDetails.service;

import com.Employee.EmployeeDetails.entity.Employee;
import com.Employee.EmployeeDetails.repository.EmployeeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepository repo;

    public EmployeeServiceImpl(EmployeeRepository repo) {
        this.repo = repo;
    }

    @Override
    public Employee save(Employee employee) {
        return repo.save(employee);
    }

    @Override
    public List<Employee> findAll() {
        return repo.findAll();
    }

    @Override
    public Employee findById(int id) {
        return repo.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Employee not found with id " + id));
    }

    @Override
    public Employee update(int id, Employee employee) {
        Employee existing = findById(id);

        existing.setFname(employee.getFname());
        existing.setLname(employee.getLname());
        existing.setEmail(employee.getEmail());
        existing.setMobilenumber(employee.getMobilenumber());
        existing.setRollnumber(employee.getRollnumber());
        existing.setDoj(employee.getDoj());
        existing.setSalary(employee.getSalary());

        return repo.save(existing);
    }
    @Override
    public void delete(int id) {
        if (!repo.existsById(id)) {
            throw new RuntimeException("Employee not found with id " + id);
        }
        repo.deleteById(id);
    }
}
