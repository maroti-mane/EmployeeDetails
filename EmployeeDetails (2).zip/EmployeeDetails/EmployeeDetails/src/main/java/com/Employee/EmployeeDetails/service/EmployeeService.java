package com.Employee.EmployeeDetails.service;

import com.Employee.EmployeeDetails.entity.Employee;

import java.util.List;

public interface EmployeeService {

    Employee save(Employee employee);

    List<Employee> findAll();

    Employee findById(int id);

    Employee update(int id, Employee employee);

    void delete(int id);
}
